# Minecraft Server

offene To Dos:

- [x] backup script erweitern / überarbeiten
- [ ] wiederherstellung prüfen
- [ ] wiederanlaufplan schreiben
- [ ] doku schreiben
- [ ] github repo erstellen
- [ ] monitoring / dashboard überarbeiten
- [x] server erreichbar machen

# Bewertung

## Backup

- [x] Inkrementelle oder Differenzielle Backups
- [x] Konfiguration des Monitoring wird gebackupt
- [ ] Ein Backup wurde erfolgreich zurückgespielt
- [x] Backups werden automatisch erstellt
- [ ] Benachrichtigung, wenn automatische Erstellung von Backups fehlschlägt (optional mittels Monitoring)

## Monitoring

- [x] Läuft
- [x] Ram-Auslastung wird überwacht
- [x] verbleibende freie Festplatenkapazität wird überwacht
- [ ] Erfolgreiche automatische Erstellung von Backups wird überwacht
- [x] Im Fehlerfall werden Benachrichtigungen „versendet“

## Automatisierung

- [x] Regelmäßige vollständige Updates gewährleisten
- [ ] Automatische Wiederherstellung möglich
- [ ] Lösung ermöglicht Review von Veränderungen (Change Management)
- [ ] Idempotente Anwendung der Konfigurationsverwaltung funktioniert fehlerfrei
- [ ] Mehrere Konfigurationen lassen sich miteinander kombinieren
- [ ] Ein einzelner Konfigurationsschritt kann einfach und sauber rückgängig gemacht werden

## Organisatorische Maßnahmen

- [x] Planung

- [ ] Dokumentation
- [ ] Versionskontrolle
- [ ] …

## Bonus

- [x] Virtualisierung, Containerisierung
- [ ] Dienste
- [ ] Skalierung
- [ ] Weitere Maßnahmen zur Steigerung der Verfügbarkeit (z.B. RAID, Netzwerkredundanz)