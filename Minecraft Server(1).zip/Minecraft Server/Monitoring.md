# Monitoring

:::info
https://raspberry.tips/raspberrypi-tutorials/raspberry-pi-monitoring-prometheus-grafana
:::

```
git clone https://github.com/raspberry-tips/raspberry-pi-monitoring
```

am ende ntfy für smartphone ziehen, push benachrichtigungen kommen damit unabhängig vom netz an, solange das topic abonniert wurde

![](/api/files/01a0f76d-bd56-7072-a513-1dd21fe43aba/ntfy_grafana-desktop.png)![](/api/files/01a0f76e-06d4-759a-a85c-824fe5973abf/ntfy_grafana-mobile.jpg)