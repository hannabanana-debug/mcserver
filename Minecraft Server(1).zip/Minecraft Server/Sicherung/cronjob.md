# cronjob

:::info
https://raspberry.tips/raspberrypi-einsteiger/cronjob-auf-dem-raspberry-pi-einrichten
:::

:::info
https://www.tecmint.com/linux-file-backup-script/
:::

`backup-FOLDER.sh` unter `home/admin/etc/cron.daily` (was in diesem Ordner liegt, wird täglich ausgeführt):

```
#!/bin/bash

# Define source and destination directories
SOURCE_DIR="/home/admin/mcserver/weltdaten"     # Source directory to back up
BACKUP_DIR="/mnt/backup/weltdaten"       # Destination directory for backups

# Create a timestamp for the backup folder
TIMESTAMP=$(date +'%Y%m%d%H%M%S')

# Create a new backup folder with the timestamp
BACKUP_FOLDER="$BACKUP_DIR/backup_$TIMESTAMP"
mkdir -p "$BACKUP_FOLDER"

# Copy files to the backup folder
cp -r "$SOURCE_DIR"/* "$BACKUP_FOLDER"

# Log the completion of the backup
echo "Backup completed at $TIMESTAMP" >> "$BACKUP_DIR/backup_log.txt"

# Optional: Remove backups older than 30 days
find "$BACKUP_DIR" -type d -name "backup_*" -mtime +30 -exec rm -rf {} \;
```

`SOURCE_DIR`: The directory containing the files you want to back up (e.g., `/home/user/Documents`).

`BACKUP_DIR`: The directory where backups will be stored (e.g., `/home/user/backups`).

`TIMESTAMP`: A variable that stores the current date and time to uniquely identify each backup folder.

`mkdir -p`: Creates the backup folder with the timestamp.

`cp -r`: Copies all files and subdirectories from the source directory to the backup folder.

The [echo command](https://www.tecmint.com/echo-command-in-linux/ "echo command in Linux") logs the backup completion and adds a timestamp to the log file.

The [find command](https://www.tecmint.com/35-practical-examples-of-linux-find-command/ "Linux Find Command") removes backups older than 30 days, keeping your backup directory from filling up with old files.