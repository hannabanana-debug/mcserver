# mount USB-drive

:::info
https://raspberry.tips/raspberrypi-tutorials/raspberry-pi-usb-festplatte-einrichten
:::

```
# in Ausgangsverzeichnis gehen
cd

# Ordner für Backups erstellen
sudo mkdir /mnt/backup

# UUID des sticks ermitteln
sudo blkid          # UUID="5A0E-861B"

# Stick mittels ID mit Ordner koppeln; nofail, damit nichts abschmiert, wenn der mal nicht gekoppelt ist; user 1000 1000 damit ich dinge copy pasten kann
sudo nano /etc/fstab       # UUID=EURE-UUID  /mnt/backup  exfat  defaults,nofail,uid=1000,gid=1000  0  0

# stick mounten
sudo mount -va
```

→ backups müssen in `/mnt/backup` geschoben werden und sind dann automatisch auf dem USB-Stick