# shrink-backup - img

:::info
https://github.com/UnconnectedBedna/shrink-backup
:::

erstellt bootbare .img dateien

## installation

```
curl https://raw.githubusercontent.com/UnconnectedBedna/shrink-backup/install/installer.sh | sudo bash
```

:::warning
USB-Stick mit exFAT(ext4)-dateifomat, um große Dateien speichern zu können
:::

```
sudo /home/admin/shrink-backup/shrink-backup -al /mnt/backup/FILENAME.img
```

`/home/admin/shrink-backup/shrink-backup` - da liegt die software shrink-backup

`-al` - kopiert alles (a) und generiert logs (l)

`/mnt/backup/FILENAME.img` - Ziel der .img