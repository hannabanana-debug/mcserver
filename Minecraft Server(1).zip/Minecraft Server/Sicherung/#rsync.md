# #rsync

manuelles Backup

rsync = vorinstalliert

ggf. mit `mkdir` Ordner für Backup erstellen

```
sudo rsync -av /home/ /mnt/backup
```

`rsync`

`-a` - Archivmodus: kopiert Unterordner rekursiv und erhält möglichst Besitzer, Rechte, Zeitstempel und symbolische Links

`-v` - verbose: zeigt an, welche Dateien kopiert werden

`-z` - Komprimierung, nur bei Übertragung via netzwerk sinnvoll

`-n` - dry run: Probelauf

`--delete` - löscht Dateien, die im Originalen Image nicht vorhanden sind

`/home/` - zu sicherndes Verzeichnis

`/media/USB-STICK/raspi/backup` - Zielverzeichnis

Daten der Welt liegen unter `/home/admin/mcserver`