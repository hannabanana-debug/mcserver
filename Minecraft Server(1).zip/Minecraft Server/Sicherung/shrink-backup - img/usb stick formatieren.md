# usb stick formatieren

:::info
https://www.diskpart.de/usb-stick-mit-diskpart-formatieren/
:::

:::info
https://learn.microsoft.com/de-de/windows-server/administration/windows-commands/diskpart
:::

```powershell
diskpart
list disk
select disk 1
clean
create partition primary
format fs=exFAT quick
```

auf dem Pi Stick prüfen:

```
lsblk -o NAME,SIZE,FSTYPE,LABEL,MOUNTPOINTS
```