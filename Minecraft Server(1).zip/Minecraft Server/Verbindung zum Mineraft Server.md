# Verbindung zum Mineraft Server

1. in Minecraft Version 26.2 (je nach latest release von papermc) starten
2. bei Multiplayer die IP des Pis als Serveradresse hinterlegen