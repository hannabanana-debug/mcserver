# #backup-monitor

```
#!/bin/bash

set -u

SOURCE_DIR="/home/admin/mcserver/weltdaten"
BACKUP_DIR="/home/admin/media/USB-STICK/raspi/backup"
METRICS_DIR="/var/lib/node_exporter/textfile_collector"
LOG_FILE="$BACKUP_DIR/backup_log.txt"

TIMESTAMP=$(date +%Y%m%d-%H%M%S)
ARCHIVE="$BACKUP_DIR/weltdaten-$TIMESTAMP.tar.gz"
METRICS_TMP="$METRICS_DIR/minecraft_backup.prom.tmp"
METRICS_FILE="$METRICS_DIR/minecraft_backup.prom"

mkdir -p "$BACKUP_DIR"
mkdir -p "$METRICS_DIR"

START=$(date +%s)

# Standardmäßig zunächst Fehler melden
cat > "$METRICS_TMP" <<EOF
minecraft_backup_success 0
minecraft_backup_last_success_timestamp 0
minecraft_backup_duration_seconds 0
minecraft_backup_size_bytes 0
EOF

# Prüfen, ob USB-Stick erreichbar ist
if [[ ! -d "/home/admin/media/USB-STICK" ]]; then
    echo "[$(date)] FEHLER: USB-Stick nicht eingebunden" >> "$LOG_FILE"
    mv "$METRICS_TMP" "$METRICS_FILE"
    exit 1
fi

# Prüfen, ob die Quelle existiert
if [[ ! -d "$SOURCE_DIR" ]]; then
    echo "[$(date)] FEHLER: Quellordner nicht gefunden: $SOURCE_DIR" >> "$LOG_FILE"
    mv "$METRICS_TMP" "$METRICS_FILE"
    exit 1
fi

echo "[$(date)] Backup gestartet" >> "$LOG_FILE"

# Archiv erstellen
if tar -czf "$ARCHIVE" -C "$(dirname "$SOURCE_DIR")" "$(basename "$SOURCE_DIR")"; then
    END=$(date +%s)
    DURATION=$((END - START))
    SIZE=$(stat -c%s "$ARCHIVE")

    cat > "$METRICS_TMP" <<EOF
minecraft_backup_success 1
minecraft_backup_last_success_timestamp $END
minecraft_backup_duration_seconds $DURATION
minecraft_backup_size_bytes $SIZE
EOF

    echo "[$(date)] Backup erfolgreich: $ARCHIVE, Größe: $SIZE Bytes" >> "$LOG_FILE"
else
    echo "[$(date)] FEHLER: tar konnte kein Backup erstellen" >> "$LOG_FILE"
    rm -f "$ARCHIVE"
fi

# Metrikdatei atomar ersetzen
mv "$METRICS_TMP" "$METRICS_FILE"

# Backups älter als 30 Tage löschen
find "$BACKUP_DIR" \
    -type f \
    -name "weltdaten-*.tar.gz" \
    -mtime +30 \
    -delete
```