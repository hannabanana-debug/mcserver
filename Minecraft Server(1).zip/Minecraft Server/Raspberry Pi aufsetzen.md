# Raspberry Pi aufsetzen

# Ersteinrichtung des Pis

:::info
https://raspberry.tips/raspberrypi-infos/installation-und-einrichtung-des-raspberry-pi
:::

:::info
https://www.raspberrypi.com/software/
:::

Raspberry Pi Imager installieren und OS entsprechend auf SD-Karte installieren

## IPv4

IP: 192.168.88.230

Subnetz: 255.255.255.0

Gateway: 192.168.88.1

DNS: 192.168.88.1

## Remote

:::info
https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html
:::

SSH aktivieren, Putty installieren

mittels SSH auf Pi-IP aufschalten und als admin anmelden

ODER

:::info
https://sourceforge.net/projects/tigervnc/
:::

TigerVNC für GUI

→ sudo raspi-config → 3 Interface Options → 3 VNC → aktivieren