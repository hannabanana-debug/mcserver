# wiederanlaufplan

sd karte mittels raspberry pi imager mit image vom stick bespielen