# Docker

:::info
https://marc.tv/minecraft-java-raspberry-pi-docker/
:::

## docker installieren

[install-docker.sh](/api/files/01a0f900-e168-7149-8ec3-8d727e602af5/install-docker.sh)

```bash
cd
mkdir mcserver
curl -fsSL https://get.docker.com -o get-docker.sh
chmod +x get-docker.sh 
./get-docker.sh 
sudo apt-get install -y uidmap
dockerd-rootless-setuptool.sh install
sudo usermod -aG docker $USER
sudo systemctl enable docker
newgrp docker
```

`cd` - home-verziechnis

`mkdir mcserver` - ordner mcserver erstellen

`curl -fsSL https://get.docker.com -o get-docker.sh` - docker installieren

`chmod +x get-docker.sh` - sh mit dockerinstallationskram ausführbar machen

`./get-docker.sh` - sh ausführen / docker installieren

`sudo apt-get install -y uidmap` - uidmap installieren, damit docker nicht im adminmodus ausgeführt wird

`dockerd-rootless-setuptool.sh install` - docker als nicht-admin-modus installieren

`sudo systemctl enable docker` - docker nach systemneustart automatisch starten

`sudo usermod -aG docker $USER` - docker gruppe anlegen und \$USER hinzufügen, damit docker ohne rootrechte ausgeführt wird

`newgrp docker` - in docker gruppe wechseln

## ~~container papermc anlegen~~

:::note
docker-compose.yml ist besser automatisierbar/bearbeitbar
:::

```bash
sudo docker run -d \
--restart unless-stopped \
--name mcserver \
-e MEMORYSIZE='1G' \
-e PAPERMC_FLAGS='' \
-v /home/pi/mcserver:/data:rw \
-p 25565:25565 \
-it marctv/minecraft-papermc-server:latest
```

~~sudo docker run -d - docker container erstellen~~

~~\--restart unless-stopped - container immer wieder neustarten, außer er wird gestoppt~~

~~\--name mcserver - name des containers~~

~~\-e MEMORYSIZE='1G' - 1GB Arbeitsspeicher im Container~~

~~\-e PAPERMC_FLAGS=’’ bewusst leer~~

~~\-v /home/admin/mcserver:/data:rw - daten in den erstellten ordner schreiben~~

~~\-p 25565:25565 - verwendet Port 25565~~

~~\-it marctv/minecraft-papermc-server:latest - verwendet neustes papermc image von marctv~~

## docker-compose.yml

[docker-compose.yml](/api/files/01a0f902-f01d-76f8-9ba9-13c298780e1a/docker-compose.yml)

→ /home/admin/mcserver/weltdaten

```
name: mcserver
services:
  mcserver:
    container_name: mcserver
    environment:
      MEMORYSIZE: 3G
      PAPERMC_FLAGS: ""
    image: marctv/minecraft-papermc-server:latest
    networks:
      default: null
    ports:
      - "25565:25565"
    restart: unless-stopped
    volumes:
      - type: bind
        source: /home/admin/mcserver/weltdaten
        target: /data
        bind: {}
networks:
  default:
    name: mcserver_default
```

### logs anschauen

```
sudo docker logs mcserver --follow
```