# Sicherung

:::info
[https://raspberry.tips/raspberrypi-tutorials/raspberry-pi-datensicherung-erstellen](https://raspberry.tips/raspberrypi-tutorials/raspberry-pi-datensicherung-erstellen#Methode_6_Nur_Dateien_per_rsync_sichern)
:::